package exercise02;

public class Exercise02 {
	
	public static void main(String args[]){
		System.out.println("Hello World!");
		System.out.println("   - written by: Lynn Robert Carter");
	}

}
